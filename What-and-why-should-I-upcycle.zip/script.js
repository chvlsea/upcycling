<div class="Downcycling">
  <div class="column1"></div>
  <div class="column2"></div>
</div>